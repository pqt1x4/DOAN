﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB3WIN
{
    public partial class Form1 : Form
    {

        int opt = -1;
        NHANVIENEntities2 db = new NHANVIENEntities2();
        public Form1()
        {
            InitializeComponent();
        }
        public void HienThiDuLieu()
        {
            DgDS.DataSource = db.chon_nv().ToList();
        }
        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDuLieu();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox1.Focus();
            opt = 1;
        
    }

        private void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                int? idNV = int.TryParse(textBox1.Text, out int id) ? id : (int?)null;
                int? tuoi = int.TryParse(textBox3.Text, out int t) ? t : (int?)null;
                int result = db.them_nv(idNV, textBox2.Text, tuoi, textBox4.Text, textBox5.Text);
                if (result > 0)
                {
                    MessageBox.Show("Thêm dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    HienThiDuLieu();
                }

                else
                {
                    MessageBox.Show("Thêm dữ liệu thất bại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DgDS_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Đảm bảo nhấp vào một hàng hợp lệ
            {
                textBox1.Text = DgDS.Rows[e.RowIndex].Cells["IDNV"].Value.ToString();
                textBox2.Text = DgDS.Rows[e.RowIndex].Cells["TEN"].Value.ToString();
                textBox3.Text = DgDS.Rows[e.RowIndex].Cells["TUOI"].Value.ToString();
                textBox4.Text = DgDS.Rows[e.RowIndex].Cells["EMAIL"].Value.ToString();
                textBox5.Text = DgDS.Rows[e.RowIndex].Cells["PB"].Value.ToString();
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Vui lòng nhập IDNV để xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }

            try
            {
                int? idNV = int.TryParse(textBox1.Text, out int id) ? id : (int?)null;
                int result = db.xoa_nv(idNV);
                if (result > 0)
                {
                    MessageBox.Show("Xóa dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    HienThiDuLieu(); // Làm mới DataGridView
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox1.Focus();
                }
                else
                {
                    MessageBox.Show("Xóa dữ liệu thất bại hoặc không tìm thấy IDNV!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Vui lòng nhập IDNV để cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }

            try
            {
                int? idNV = int.TryParse(textBox1.Text, out int id) ? id : (int?)null;
                int? tuoi = int.TryParse(textBox3.Text, out int t) ? t : (int?)null;
                int result = db.sua_nv(idNV, textBox2.Text, tuoi, textBox4.Text, textBox5.Text);
                if (result > 0)
                {
                    MessageBox.Show("Cập nhật dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    HienThiDuLieu(); // Làm mới DataGridView
                }
                else
                {
                    MessageBox.Show("Cập nhật dữ liệu thất bại hoặc không tìm thấy IDNV!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Bạn có chắc chắn muốn thoát?", "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close(); // Đóng form hiện tại
            }
        }
    }
}
